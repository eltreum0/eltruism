local ElvUI_EltreumUI, E, L, V, P, G = unpack(select(2, ...))

-- EltreumUI Global DB
G.ElvUI_EltreumUI = {}
